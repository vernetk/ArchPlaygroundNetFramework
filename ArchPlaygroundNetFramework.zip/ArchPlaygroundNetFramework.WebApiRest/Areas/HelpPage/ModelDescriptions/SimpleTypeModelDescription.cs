namespace ArchPlaygroundNetFramework.WebApiRest.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}